##  Ganon Castle/ Crumbling Ganon Castle
()

Autosaved at 2026/11/23 at 12:53:01  
Progress: [🟢|💡🥷👻]   
❤️ 20/20  
❇️ 237/240  
💀 22 💰️ 100  
Songs: [💤🌲|🌲🌋]  

![](caption.jpg)


<!-- 47 entries:
  0x89ae7032 ShadowMedallion =  1
  0x50c6bedf GoronRuby =  0
  0x238ae327 SongZelda =  1
  0xf941212 SongSaria =  1
  0xab6b5962 SongStorms =  0
  0x380a5616 SongTime =  0
  0xe1ca50c6 WaterMedallion =  0
  0x75bd1ecf ForestMedallion =  0
  0x2f61ab71 ZoraSapphire =  0
  0x17464eb8 SongFire =  1
  0x10dc0608 FireMedallion =  0
  0xfb2b5f6b SongSuns =  0
  0x85f5194d SongWater =  0
  0xba6a1b74 SpiritMedallion =  1
  0x2f793671  =  0
  0x59ce596 LightMedallion =  1
  0x91288adc SongEpona =  0
  0x1eda08d5  =  0
  0x574aef59 SongShadow =  0
  0x25f03caa AutoSaveMarker =  1
  0xc72044fc PostGame =  0
  0xf9d63fd4 SongLight =  0
  0x99b50b91 SongForest =  1
  0x7c5b03dc FieldMusicStart =  1
  0x83254520 SongSpirit =  0
  0xe8bd6759 DoubleDefense =  0
  0xfb112756 KokiriEmerald =  1
  0xdc941483 GSCount =  22
  0xbd46f485 FileSaved_Day =  23
  0x23f3d75e FileSaved_Hour =  12
  0x5ee50bed FileSaved_Second =  1
  0x9811a3f7 FileSaved_Year =  2026
  0x27853bf7 FileSaved_Minute =  53
  0xdfd840d3 FileSaved_Month =  11
  0x943f8ec3 MagicMax =  240
  0x1e55ecc5 HeartsCurr =  20
  0x74bd05d0 HeartsMax =  20
  0x19f26b6a MagicCurr =  237
  0xa9557547 RupeeCount =  100
  0xaccbda17  =  3257973976
  0x8b26618e  =  672
  0xcccc6cd  =  684
  0xf74e0e8e  =  748
  0x47c0901e  =  812
  0x63696a32  =  1392
  0x51c58419  =  0
  0x26f3523b  =  0
-->