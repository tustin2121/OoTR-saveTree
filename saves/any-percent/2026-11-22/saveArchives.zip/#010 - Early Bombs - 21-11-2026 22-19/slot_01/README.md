##  Death Mountain Trail/ Death Mountain Trail_ Child
(DeathMountainTrail)

Autosaved at 2026/11/21 at 22:18:13  
Progress: [🟢|]   
❤️ 6/12  
💀 0 💰️ 30  
Songs: [💤🌲|]  

![](caption.jpg)


<!-- 47 entries:
  0x89ae7032 ShadowMedallion =  0
  0x50c6bedf GoronRuby =  0
  0x238ae327 SongZelda =  1
  0xf941212 SongSaria =  1
  0xab6b5962 SongStorms =  0
  0x380a5616 SongTime =  0
  0xe1ca50c6 WaterMedallion =  0
  0x75bd1ecf ForestMedallion =  0
  0x2f61ab71 ZoraSapphire =  0
  0x17464eb8 SongFire =  0
  0x10dc0608 FireMedallion =  0
  0xfb2b5f6b SongSuns =  0
  0x85f5194d SongWater =  0
  0xba6a1b74 SpiritMedallion =  0
  0x2f793671  =  0
  0x59ce596 LightMedallion =  0
  0x91288adc SongEpona =  0
  0x1eda08d5  =  0
  0x574aef59 SongShadow =  0
  0x25f03caa AutoSaveMarker =  1
  0xc72044fc PostGame =  0
  0xf9d63fd4 SongLight =  0
  0x99b50b91 SongForest =  0
  0x7c5b03dc FieldMusicStart =  1
  0x83254520 SongSpirit =  0
  0xe8bd6759 DoubleDefense =  0
  0xfb112756 KokiriEmerald =  1
  0xdc941483 GSCount =  0
  0xbd46f485 FileSaved_Day =  21
  0x23f3d75e FileSaved_Hour =  22
  0x5ee50bed FileSaved_Second =  13
  0x9811a3f7 FileSaved_Year =  2026
  0x27853bf7 FileSaved_Minute =  18
  0xdfd840d3 FileSaved_Month =  11
  0x943f8ec3 MagicMax =  0
  0x1e55ecc5 HeartsCurr =  6
  0x74bd05d0 HeartsMax =  12
  0x19f26b6a MagicCurr =  0
  0xa9557547 RupeeCount =  30
  0xaccbda17  =  1114747046
  0x8b26618e  =  672
  0xcccc6cd  =  684
  0xf74e0e8e  =  748
  0x47c0901e  =  812
  0x63696a32  =  1392
  0x51c58419  =  0
  0x26f3523b  =  0
-->